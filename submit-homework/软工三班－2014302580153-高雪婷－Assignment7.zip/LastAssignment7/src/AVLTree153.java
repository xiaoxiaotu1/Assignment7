/**
 * Created by gaoxueting on 16/1/2.
 */

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree153<T extends Comparable< ? super T>> implements IAVLTree {

    private Node root;//根节点

    public AVLTree153( ) {
        root = null;
    }

    private void rotateRight(Node n) {          //右旋算法

        boolean isTrue = true; //利用布尔表达式进行真假判断
        if (n != null) {
            isTrue = false;
        }
        if (isTrue=false) {                        //不为空时开始计算，否则直接返回

            n.setRight(n.right().left());      //将n的右孩子的左孩子设置为右孩子
            while (n.right().left() != null) { //当n右孩子的左孩子不为空时，将其设立为parent
                n.right().left().setParent(n);
            }
            n.right().setParent(n.parent());   //将n的parent作为setParent的变量，设置给n的右孩子

            if (n.parent().left() == n) {      //当n是n父母的左孩子时，对n的父母的子节点进行一些修改
                n.parent().setLeft(n.right());
            } else if (n.parent().right() == n) {   //此时n是右孩子
                n.parent().setRight(n.right());
            } else {
                root = n.right();
                ; //n是根节点时，令根节点等于n的右孩子
            }
            n.right().setLeft(n);               //设定孩子和父母
            n.setParent(n.right());
        } else {
            System.out.println("The root is empty.");
            return;
        }
    }

    private void rotateLeft(Node n) {

        boolean isTrue = true; //利用布尔表达式进行真假判断
        if (n != null) {
            isTrue = false;
        }
        if (isTrue=false) {
            //不为空时开始计算，否则直接返回
            n.setLeft(n.left().left());         //将n左孩子的左孩子设置为左孩子
            while (n.left().left() != null) {   //不为空时设置为parent
                n.left().right().setParent(n);
            }
            n.left().setParent(n.parent());     //将n的parent作为setParent的变量设置给n的左孩子

            if (n.parent().right() == n) {      //当n是右孩子时，对n父母的子节点进行一些更改
                n.parent().setRight(n.left());
            } else if (n.parent() == null) {    //n是根节点时
                root = n.left();
            } else {
                n.parent().setLeft(n.left());   //n是左孩子
            }
            n.left().setRight(n);               //设定孩子和父母
            n.setParent(n.left());
        } else {
            System.out.println("The root is empty.");
            return;
        }
    }


    private void adjustAfterInsertion(Node n){   //insert之后可用的调整算法
        if(n.balance == 2){
            leftBalance(n);
        }
        if(n.balance == -2){
            rightBalance(n);
        }
    }
    @Override
    public void insert(Node n) {

        if (root == null) {                     //树为空时，将其当作根，最后返回
            n.setBalance(0);
            root = n;
        } else {
            addNode(n);
        }
    }
    private void addNode(Node n) {
        int LeftOrRight;                     //左孩子和右孩子这一项的值不同，可作为判断依据
        Node parent = null;                    //保存n的父母节点

        while (root != null) {                     //当根节点不为空时,设置父母
            parent = root;
            n.setParent(parent);

            LeftOrRight = n.id() - root.id(); //该判据的计算为该孩子ID与父母的ID相减

            if (LeftOrRight == 0) {                 //该判据的三种情况
                System.out.println("The node" + n.id() + "has existed,which you can't insert");//相等无法插入
            } else if (LeftOrRight < 0) {           //小于零说明是左孩子
                root = root.left();
                parent.setLeft(n);
            } else {                              //大于零则是右孩子
                root = root.right();
                parent.setRight(n);
            }
        }

        boolean isTrue = true;
        if (parent != null) {
            isTrue = true;
        }
        if (isTrue=true) {                   //该判据与平衡因子设定的关系。当父母不为空时。
            LeftOrRight = n.id() - parent.id();

            if (LeftOrRight > 0) {                  //右孩子时平衡因子减一
                parent.setBalance(parent.balance() - 1);
            } else if (LeftOrRight < 0) {            //左孩子时加一
                parent.setBalance(parent.balance() + 1);
            }

            switch (parent.balance()) {  //平衡因子是零时直接退出；还有其他两种情况
                case 0: {
                    break;
                }
                case -2: {
                    adjustAfterInsertion(parent);       //分别调用leftBalance和rightBalance函数
                    break;
                }
                case 2: {
                    adjustAfterInsertion(parent);
                    break;
                }
            }
            parent = parent.parent();           //最后设定parent
        }
    }

    private boolean leftBalance(Node n) {    //添加和删除函数中用到的左右平衡函数

        if (n.left().balance() == 1) {    //当该节点的左孩子的平衡因子分别为1，0，－1时的情况
            n.setBalance(0);          //每种情况都设定n的平衡因子和n左孩子的平衡因子，并进行左旋或右旋
            n.left().setBalance(0);
            rotateLeft(n);
        } else if (n.left().balance() == 0) {
            n.left().setBalance(-1);
            n.setBalance(1);
            rotateLeft(n);
            System.out.println("You can't balance from the left.");
            return false;                   //平衡因子是零的时候要返回false
        } else if (n.left().balance() == -1) {

            if (n.left().balance() == 0) {
                n.setBalance(0);
                n.left().setBalance(0);
            } else if (n.left().right().balance() == 1) {//此处还要考虑左孩子的右孩子的平衡因子
                n.setBalance(-1);
                n.left().setBalance(0);
            } else if (n.left().balance() == -1) {
                n.setBalance(0);
                n.left().setBalance(1);
            }
            n.left().right().setBalance(0);
            rotateRight(n.left());
            rotateLeft(n);
        }
        return true;   //返回真时真正在平衡因子和左旋的作用下进行了左平衡
    }


    private boolean rightBalance(Node n) {             //右平衡函数

        if (n.right().balance() == 1) {            //当该节点右孩子的平衡因子分别是1，0和－1的情况

            if (n.left().balance() == 1) {          //右孩子平衡因子为1时，当n的左孩子分别为1，0，－1时，
                n.setBalance(0);                //分别设定n的平衡因子和n的右孩子的平衡因子
                n.right().setBalance(-1);
            } else if (n.left().balance() == 0) {
                n.setBalance(0);
                n.right().setBalance(0);
            } else if (n.left().balance() == -1) {
                n.setBalance(1);
                n.right().setBalance(0);
            }
            n.left().setBalance(0);             //设定好平衡因子后，最后再进行左旋和右旋
            rotateLeft(n.right());
            rotateRight(n);
        } else if (n.right().balance() == 0) {
            n.right().setBalance(1);
            n.setBalance(-1);
            rotateRight(n);
            System.out.println("You can't balance from the right.");
            return false;//平衡因子为零时，需要返回false
        } else if (n.right().balance() == -1) {
            n.setBalance(0);
            n.right().setBalance(0);
            rotateRight(n);
        }
        return true;                                 //返回真时在平衡因子和右旋函数的基础上进行了右平衡
    }


    @Override
    public Node get(int id) {

        boolean isTrue = true; //利用布尔表达式进行真假判断
        if (root != null) {
            isTrue = false;
        }
        int LeftOrRight;              //通过该节点的ID与根节点ID的差为正或负，确定该取为左孩子还是右孩子
        if (isTrue=false) {
            LeftOrRight = id - root.id(); //再次使用该表达式

            //该判据大于，等于或小于零三种情况，分别返回左右根节点（不要在乎语序）
            if (LeftOrRight == 0) {
                System.out.println("Find Successfully!");
                return root;
            } else if (LeftOrRight < 0) {
                root = root.left();
            } else {
                root = root.right();
            }
        } else {
            return root;
        }
        System.out.println("There isn't anything you need.");
        return root;
    }


    @Override
    public void delete(int id) {      //删除函数
        Node node = get(id);

        if (node == null) {          //当节点为空时直接返回
            return;
        } else {

            if (node.left() != null && node.right() != null) {  //此时有左右两个孩子

                Node s=node.right();
                while(node.right().left()!=null){
                   s=node.right().left();
                }
                swapData(node,s);
                node=s;
            }

            Node oneChild = (node.left() != null ? node.left() : node.right()); //通过这一关系式确定是否只有一个孩子
            if (oneChild != null) {
                oneChild.setParent(node.parent());
                if (node.parent() == null) {               //只有根节点
                    root = oneChild;
                } else if (node == node.parent().left()) { //只有左孩子
                    node.parent().setLeft(oneChild);
                } else {                               //只有右孩子时，设置右孩子
                    node.parent().setRight(oneChild);
                }

                node.setParent(null);
                node.setLeft(null);
                node.setRight(null);

                reBalance(oneChild);               //调用重新平衡函数
            } else if (node.parent() == null) {         //全树只有一个节点，即根节点
                root = null;
            } else {                                 //左右子树都为空时
                reBalance(node);

                if (node.parent() != null) {
                    if (node == node.parent().left()) { //当该节点是其父母的左子树或者右子树时分别设定父母
                        node.parent().setLeft(null);
                    } else if (node == node.parent().right()) {
                        node.parent().setRight(null);
                    }
                    node.setParent(null);
                }

            }

        }
    }
    private void swapData(Node a, Node b){
        int tempId = a.id();
        Object tempData = a.data();
        a.setId(b.id());
        a.setData(b.data());
        b.setId(tempId);
        b.setData(tempData);
    }

    private void reBalance(Node node) {   //在删除操作之中重新平衡

        Node parent = node.parent();
        boolean heightLower = true;        //看最小子树调整后，它的高度是否发生变化，如果减小，继续回溯

        int LeftOrRight;
        while (heightLower = true && parent != null) {
            LeftOrRight = node.id() - parent.id();//又一次使用该表达式
            boolean isTrue = true;
            if (LeftOrRight < 0) {
                isTrue = false;
            } else {
                isTrue = true;
            }
            if (isTrue=false) {
                parent.setBalance(parent.balance() - 1);
            } else {
                parent.setBalance(parent.balance() + 1);
            }

            switch (parent.balance()) { //当父母的平衡因子分别为1，－1，2，－2时的调整
                case 1: {
                    break;
                }
                case -1: {
                    break;
                }
                case 2: {
                    heightLower = leftBalance(parent); //-2,2时调用左右平衡函数
                }
                case -2: {
                    heightLower = rightBalance(parent);
                }
            }
            parent = parent.parent();
        }
    }
    public void makeEmpty( )
    {
        root = null;
    }

    public boolean isEmpty( )
    {
        return root == null;
    }

    @Override
    public JTree printTree(){ //  打印树的算法
        DefaultMutableTreeNode tree=new DefaultMutableTreeNode(root.data().toString()+"#"+root.id());
        JTree Jtree=new JTree(tree);
        printTree(tree,root);
        return Jtree;
    }

    public  JTree printTree(DefaultMutableTreeNode tree,Node root){

        boolean isTrue=true;
        if(root.left()!=null){
            isTrue=true;
        }

        if(root!=null){
            if(isTrue){
                DefaultMutableTreeNode l=new DefaultMutableTreeNode(root.data().toString()+"#"+root.id());
                tree.add(l);
                printTree(tree,root.left());
            }
            if(!isTrue){
                DefaultMutableTreeNode r=new DefaultMutableTreeNode(root.data().toString()+"#"+root.id());
                tree.add(r);
                printTree(tree,root.right());
            }
        }
            return null;
        }
    }


