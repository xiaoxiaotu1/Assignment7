/**
 * Created by gaoxueting on 16/1/2.
 */
//关于其中两个类的名字，由于写实验报告的时候很早，真正开始写代码的时候略有改动，望见谅

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

public class AVLTree153 implements IAVLTree {

    private int size = 0;                         //初始化树中元素个数
    private Node root = null;                     //根节点

    private void rotateRight(Node n) {          //右旋算法

        if (n != null) {                        //不为空时开始计算，否则直接返回

            n.setRight(n.right().left());      //将n的右孩子的左孩子设置为右孩子
            while (n.right().left() != null) { //当n右孩子的左孩子不为空时，将其设立为parent
                n.right().left().setParent(n);
            }
            n.right().setParent(n.parent());   //将n的parent作为setParent的变量，设置给n的右孩子

            if (n.parent().left() == n) {      //当n是n父母的左孩子时，对n的父母的子节点进行一些修改
                n.parent().setLeft(n.right());
            } else if (n.parent().right() == n) {   //此时n是右孩子
                n.parent().setRight(n.right());
            } else {
                root = n.right();
                ; //n是根节点时，令根节点等于n的右孩子
            }
            n.right().setLeft(n);               //设定孩子和父母
            n.setParent(n.right());
        } else {
            return;
        }
    }

    private void rotateLeft(Node n) {

        if (n != null) {
            //不为空时开始计算，否则直接返回
            n.setLeft(n.left().left());         //将n左孩子的左孩子设置为左孩子
            while (n.left().left() != null) {   //不为空时设置为parent
                n.left().right().setParent(n);
            }
            n.left().setParent(n.parent());     //将n的parent作为setParent的变量设置给n的左孩子

            if (n.parent().right() == n) {      //当n是右孩子时，对n父母的子节点进行一些更改
                n.parent().setRight(n.left());
            } else if (n.parent() == null) {    //n是根节点时
                root = n.left();
            } else {
                n.parent().setLeft(n.left());   //n是左孩子
            }
            n.left().setRight(n);               //设定孩子和父母
            n.setParent(n.left());
        } else {
            return;
        }
    }

    @Override
    public void insert(Node n) {

        while (root == null) {                     //树为空时，将其当作根，最后返回
            n.setBalance(0);
            root = n;
            size = 1;
            return;
        }

        int LeftOrRight;                       //左孩子和右孩子这一项的值不同，可作为判断依据
        Node parent = null;                    //保存n的父母节点

        while (root != null) {                     //当根节点不为空时,设置父母
            parent = root;
            n.setParent(parent);

            LeftOrRight = n.id() - root.id(); //该判据的计算为该孩子ID与父母的ID相减

            if (LeftOrRight == 0) {                 //该判据的三种情况
                System.out.println("该节点" + n.id() + "存在，无法插入");//相等无法插入
            } else if (LeftOrRight < 0) {           //小于零说明是左孩子
                root = root.left();
                parent.setLeft(n);
            } else {                              //大于零则是右孩子
                root = root.right();
                parent.setRight(n);
            }
        }
        size++;                                 //元素长度加一

        while (parent != null) {                   //该判据与平衡因子设定的关系。当父母不为空时。
            LeftOrRight = n.id() - parent.id();

            if (LeftOrRight > 0) {                  //右孩子时平衡因子减一
                parent.setBalance(parent.balance() - 1);
            } else if (LeftOrRight < 0) {            //左孩子时加一
                parent.setBalance(parent.balance() + 1);
            }

            switch (parent.balance()) {  //平衡因子是零时直接退出；还有其他两种情况
                case 0: {
                    break;
                }
                case -2: {
                    rightBalance(parent);       //分别调用leftBalance和rightBalance函数
                    break;
                }
                case 2: {
                    leftBalance(parent);
                    break;
                }
            }
            parent = parent.parent();           //最后设定parent
        }
    }


    private boolean leftBalance(Node n) {    //添加和删除函数中用到的左右平衡函数

        if (n.left().balance() == 1) {    //当该节点的左孩子的平衡因子分别为1，0，－1时的情况
            n.setBalance(0);          //每种情况都设定n的平衡因子和n左孩子的平衡因子，并进行左旋或右旋
            n.left().setBalance(0);
            rotateLeft(n);
        } else if (n.left().balance() == 0) {
            n.left().setBalance(-1);
            n.setBalance(1);
            rotateLeft(n);
            return false;                   //平衡因子是零的时候要返回false
        } else if (n.left().balance() == -1) {

            if (n.left().balance() == 0) {
                n.setBalance(0);
                n.left().setBalance(0);
            } else if (n.left().right().balance() == 1) {//此处还要考虑左孩子的右孩子的平衡因子
                n.setBalance(-1);
                n.left().setBalance(0);
            } else if (n.left().balance() == -1) {
                n.setBalance(0);
                n.left().setBalance(1);
            }
            n.left().right().setBalance(0);
            rotateRight(n.left());
            rotateLeft(n);
        }
        return true;   //返回真时真正在平衡因子和左旋的作用下进行了左平衡
    }


    private boolean rightBalance(Node n) {             //右平衡函数

        if (n.right().balance() == 1) {            //当该节点右孩子的平衡因子分别是1，0和－1的情况

            if (n.left().balance() == 1) {          //右孩子平衡因子为1时，当n的左孩子分别为1，0，－1时，
                n.setBalance(0);                //分别设定n的平衡因子和n的右孩子的平衡因子
                n.right().setBalance(-1);
            } else if (n.left().balance() == 0) {
                n.setBalance(0);
                n.right().setBalance(0);
            } else if (n.left().balance() == -1) {
                n.setBalance(1);
                n.right().setBalance(0);
            }
            n.left().setBalance(0);             //设定好平衡因子后，最后再进行左旋和右旋
            rotateLeft(n.right());
            rotateRight(n);
        } else if (n.right().balance() == 0) {
            n.right().setBalance(1);
            n.setBalance(-1);
            rotateRight(n);
            return false;                            //平衡因子为零时，需要返回false
        } else if (n.right().balance() == -1) {
            n.setBalance(0);
            n.right().setBalance(0);
            rotateRight(n);
        }
        return true;                                 //返回真时在平衡因子和右旋函数的基础上进行了右平衡
    }


    @Override
    public Node get(int id) {

        int LeftOrRight;              //通过该节点的ID与根节点ID的差为正或负，确定该取为左孩子还是右孩子
        if (root != null) {
            LeftOrRight = id - root.id(); //再次使用该表达式

            if (LeftOrRight == 0) {        //该判据大于，等于或小于零三种情况，分别返回左右根节点（不要在乎语序）
                return root;
            } else if (LeftOrRight < 0) {
                root = root.left();
            } else {
                root = root.right();
            }
        } else {
            return null;
        }
        return null;
    }


    @Override
    public void delete(int id) {      //删除函数
        size--;                      //元素长度减一
        Node node = get(id);

        while (node == null) {          //当节点为空时直接返回
            return;
        }

        if (node.left() != null && node.right() != null) {  //此时有左右两个孩子
            Node changeParentAndChild = changeParentAndChild(node);   //此函数在下面有声明
            node.setId(changeParentAndChild.id());    //分别设置id和data
            node.setData(changeParentAndChild.data());
            node = changeParentAndChild;
        }

        Node oneChild = (node.left() != null ? node.left() : node.right()); //通过这一关系式确定是否只有一个孩子
        if (oneChild != null) {
            oneChild.setParent(node.parent());
            if (node.parent() == null) {               //只有根节点
                root = oneChild;
            } else if (node == node.parent().left()) { //只有左孩子
                node.parent().setLeft(oneChild);
            } else {                               //只有右孩子时，设置右孩子
                node.parent().setRight(oneChild);
            }

            node.setParent(null);
            node.setLeft(null);
            node.setRight(null);

            reBalance(oneChild);               //调用重新平衡函数
        } else if (node.parent() == null) {         //全树只有一个节点，即根节点
            root = null;
        } else {                                 //左右子树都为空时
            reBalance(node);

            if (node.parent() != null) {
                if (node == node.parent().left()) { //当该节点是其父母的左子树或者右子树时分别设定父母
                    node.parent().setLeft(null);
                } else if (node == node.parent().right()) {
                    node.parent().setRight(null);
                }
                node.setParent(null);
            }

        }

    }


    private void reBalance(Node node) {   //在删除操作之中重新平衡

        Node parent = node.parent();
        boolean heightLower = true;        //看最小子树调整后，它的高度是否发生变化，如果减小，继续回溯

        int LeftOrRight;
        while (heightLower = true && parent != null) {
            LeftOrRight = node.id() - parent.id();//又一次使用该表达式
            if (LeftOrRight < 0) {
                parent.setBalance(parent.balance() - 1);
            } else {
                parent.setBalance(parent.balance() + 1);
            }

            switch (parent.balance()) { //当父母的平衡因子分别为1，－1，2，－2时的调整
                case 1: {
                    break;
                }
                case -1: {
                    break;
                }
                case 2: {
                    heightLower = leftBalance(parent); //-2,2时调用左右平衡函数
                }
                case -2: {
                    heightLower = rightBalance(parent);
                }
            }
            parent = parent.parent();
        }
    }

    private Node changeParentAndChild(Node n) {  //自顶向下地让孩子变成新一轮的家长
        while (n == null) {   //为根节点时返回空
            return null;
        }

        if (n.right() != null) {    //当右孩子为空与不为空发生讨论
            Node parent = n.right();
            if (parent.left() != null) { //有做了家长的右孩子有左孩子时，让左孩子作家长
                parent = parent.left();
            }
            return parent;
        } else {
            Node parent = n.parent();
            if (parent != null && n == parent.right()) {//当父母不为空且该节点为右孩子时，令该节点作父母
                n = parent;
                parent = parent.parent();
            }
            return parent;
        }

    }

    @Override
    public JTree printTree() {    //能让该二叉树可视化的方法

        while (root == null) {       //根不为空时
            return null;
        }

        DefaultMutableTreeNode root = createNewNode(this.root); //新建一个根节点
        JTree jtree = new JTree(root);                          //由根节点新建一棵树
        return jtree;
    }

    public void inFirstOrder() {

        while (root == null) {
            System.out.println("树为空"); //树为空时检查可用
            return;
        }
        inRightOrder(root);

    }

    private void inRightOrder(Node n) {
        while (n == null) {     //节点为空时返回
            return;
        }
        inRightOrder(n.left()); //获取左孩子，右孩子
        inRightOrder(n.right());
        System.out.println("id: " + n.id() + "\tdata: " + n.data());//输出id以及data
    }


    private DefaultMutableTreeNode createNewNode(Node n) {  // JTree中调用的函数
        DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(n);
        if (n.right() != null) {    //需要的时候加上左孩子或右孩子
            newNode.add(createNewNode(n.right()));
        }
        if (n.left() != null) {
            newNode.add(createNewNode(n.left()));
        }
        return newNode;  //返回一个新节点
    }
}
