
public class Node {
	private int id; //地址
	private Object data; //数据
	private Node[] children = new Node[2]; //孩子
	private Node parent; //父母
	public int balance; //平衡因子

	@Override
	public String toString() //文本写入方法
	{
		if (this.data() != null)
			return "id:" + String.valueOf(this.id()) + " data:" + String.valueOf(this.data());
		else
			return "id:" + String.valueOf(this.id());
	}

	public void setId(int id) {
		this.id = id;
	}

	public int id() {
		return id;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public void setChildren(Node[] children) {
		this.children = children;
	}

	public Object data() {
		return data;
	}

	public void setChild(int id, Node child) {
		this.children[id] = child;
	}

	public Node[] children() {
		return children;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	public Node parent() {
		return parent;
	}

	public void setBalance(int balance) {  //平衡因子
		this.balance = balance;
	}

	public int balance() {
		return balance;
	}

	public void setLeft(Node left) { //左孩子，调用setChild函数
		setChild(0, left);
	}

	public Node left() {  //左孩子，返回孩子函数［0］
		return children()[0];
	}

	public void setRight(Node right) { //右孩子，调用setChild函数
		setChild(1, right);
	}

	public Node right() {
		return children()[1];  //右孩子，返回孩子函数［0］
	}

	public Node children(int id) { //获取孩子的方法
		if (id == 0 || id == 1) {
			return children[id];
		}
		else{
			return null;}
	}
}