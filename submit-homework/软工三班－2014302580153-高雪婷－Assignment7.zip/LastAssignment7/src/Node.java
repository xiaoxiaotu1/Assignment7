
public class Node {
	private int id; //地址
	private Object data; //数据
	private Node[] children = new Node[2]; //孩子
	private Node parent; //父母
	private int balance; //平衡因子

	@Override
	public String toString() {  //读取文本
		return "id:" + id() + "data:" + data();
	}

	public void setId(int id) {
		this.id = id;
	}

	public int id() {
		return id;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Object data() {
		return data;
	}
	public void setChild(int id,Node child) {
		this.children[id] = child;
	}

	public Node[] children() {
		return children;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	public Node parent() {
		return parent;
	}

	public void setBalance(int balance) {  //平衡因子
		this.balance = balance;
	}

	public int balance() {
		return balance;
	}

	public void setLeft(Node left) { //左孩子，调用setChild函数
		setChild(0,left);
	}

	public Node left() {  //左孩子，返回孩子函数［0］
		return children()[0];
	}

	public void setRight(Node right) { //右孩子，调用setChild函数
		setChild(1,right);
	}

	public Node right() {
		return children()[1];  //右孩子，返回孩子函数［0］
	}

}

