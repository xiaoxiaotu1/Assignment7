/**
 * Created by gaoxueting on 16/1/3.
 */
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Frame153 extends JFrame{

    JTree jtree;
    AVLTree153 avlTree;

    public Frame153(final AVLTree153 avlTree){ //avlTree的界面
        super("AVLTree");
        this.avlTree=avlTree;
        setSize(600,600);                //确定大小等等并根据JTree作出可视化的树
        setLayout(null);
        setResizable(false);
        this.jtree=avlTree.printTree();
        addJTree();

        JLabel jLabel=new JLabel("您要查找的二叉树中节点的ID为：");//设立标签并确定标签大小
        jLabel.setBounds(5,400,100,30);
        add(jLabel);

        final JLabel fruitLabel=new JLabel(); //用来响应的label
        fruitLabel.setBounds(400,450,150,30);
        add(fruitLabel);

        final JTextField jTextField=new JTextField(); //输入节点的区域
        jTextField.setBounds(120,300,50,30);
        add(jTextField);

        JButton jButton=new JButton("Enter");  //加入一个按钮
        jButton.setBounds(280,450,50,30);
        jButton.addActionListener(new ActionListener() { //加入活动的监听
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    int id=Integer.parseInt(jTextField.getText()); //爬下来id值
                    Node fruit=avlTree.get(id);
                    if(fruit!=null){  //id不为空时输出，文本转换；为空时报错
                        fruitLabel.setText(fruit.toString());
                    }else{
                        fruitLabel.setText("搜索失败");
                    }
                }catch(NumberFormatException err){ //错误处理
                    JOptionPane.showMessageDialog(null,"输入数字：","失败",JOptionPane.ERROR_MESSAGE);
                    err.printStackTrace();
                }
            }
        });
        add(jButton);

        JLabel inLabel=new JLabel("您要插入的平衡二叉树节点的ID和data分别为（id＋data):");//加入另一个标签
        inLabel.setBounds(150, 550, 200, 30);
        add(inLabel);

        final JTextField inTextField=new JTextField(); //另一个书写区域
        inTextField.setBounds(150,480,50,30);
        add(inTextField);

        JButton inButton=new JButton("Enter"); //新的按钮
        inButton.setBounds(150,550,50,30);
        inButton.addActionListener(new ActionListener() { //新的行为监听器
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    String[] text=inTextField.getText().split("\\+");
                    if(text.length==2){  //根据输入的Text对应找到其id及data
                        int id=Integer.parseInt(text[0]);//text的第一段为id ,第二段为data
                        jtree.setVisible(false);
                        remove(jtree);
                        Node node=new Node();
                        node.setId(id);
                        String data=text[1];
                        node.setData(data);
                        Frame153.this.avlTree.insert(node);//插入avlTree
                        jtree=Frame153.this.avlTree.printTree();//显示avlTree
                        addJTree();
                    }else{ //报错
                        JOptionPane.showMessageDialog(null,"您输入的格式错误","失败",JOptionPane.ERROR_MESSAGE);
                    }
                }catch(NumberFormatException err){
                    JOptionPane.showMessageDialog(null,"输入数字：","失败" ,JOptionPane.ERROR_MESSAGE);
                    inTextField.setText("");
                    err.printStackTrace();
                }
            }
        });
        add(inButton);

        JLabel deLabel=new JLabel("您要删除的二叉树的节点ID为：");//新的标签
        deLabel.setBounds(400,460,100,30);
        add(deLabel);

        final JTextField deTextField=new JTextField();//新的文字区域
        deTextField.setBounds(400,500,50,30);
        add(deTextField);

        JButton deButton=new JButton("Enter"); //新按钮
        deButton.setBounds(400,500,50,30);
        deButton.addActionListener(new ActionListener() {//行为监听器
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Frame153.this.avlTree.delete(Integer.parseInt(deTextField.getText()));//删除操作
                    jtree.setVisible(false);
                    remove(jtree);
                    jtree=Frame153.this.avlTree.printTree();
                    addJTree();
                }catch(NumberFormatException err){//报错
                    JOptionPane.showMessageDialog(null,"输入数字：","失败",JOptionPane.ERROR_MESSAGE);
                    deTextField.setText("");
                    err.printStackTrace();
                }
            }
        });
        add(deButton);

    }

    private void addJTree(){  //将实例化的二叉树加入的函数
        while(jtree!=null){
            jtree.setBounds(50, 30, 500, 300);
            jtree.setVisible(true);
            add(jtree);
        }
    }
}
