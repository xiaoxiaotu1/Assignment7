/**
 * Created by gaoxueting on 16/1/3.
 */
import javax.swing.*;
import java.awt.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.ActionListener;

public class Frame153 extends JFrame{

    JTree jtree;
    AVLTree153 avlTree;

    public Frame153(final AVLTree153 avlTree){ //avlTree的界面
        setTitle("test for AVLTree");
        this.avlTree=avlTree;
        setLayout(null);
        setResizable(false);
        setSize(600,600);                //确定大小等等并根据JTree作出可视化的树
        this.jtree=avlTree.printTree();
        addJTree();

        JPanel panel=new ImagePanel(); //调用后面的ImagePanel函数，来实现图片背景
        getContentPane().add(panel);
        panel.setLayout(null);

        Image image=Toolkit.getDefaultToolkit().getImage("./src/Icon.png");
        setIconImage(image);

        final JLabel fruitLabel=new JLabel(); //用来响应的label
        JLabel jlabel=new JLabel("<HTML><U>您要查找的二叉树中节点的ID为：</U></HTML>");//设立标签并确定标签大小
        JLabel inLabel=new JLabel("<HTML><U>您要插入的平衡二叉树节点的ID和data分别为（id＋data):</U></HTML>");//加入另一个标签
        JLabel deLabel=new JLabel("<HTML><U>您要删除的二叉树的节点ID为：</U></HTML>");//新的标签

        fruitLabel.setBounds(400,470,150,30); //设置label的边界
        jlabel.setBounds(5,400,100,30);
        inLabel.setBounds(150, 550, 200, 30);
        deLabel.setBounds(new Rectangle(400,470,100,30));

        jlabel.setFont(new Font("",1,18)); //设置label的字体大小
        inLabel.setFont(new Font("",1,18));
        deLabel.setFont(new Font("",1,18));

        this.getContentPane().add(jlabel);  //加入做好的标签
        this.getContentPane().add(inLabel);
        add(fruitLabel);
        this.getContentPane().add(deLabel);

        final JTextField jTextField=new JTextField(); //输入节点的区域
        final JTextField inTextField=new JTextField(); //另一个书写区域
        final JTextField deTextField=new JTextField();//新的文字区域

        jTextField.setBounds(120,300,50,30);
        inTextField.setBounds(150,480,50,30);
        deTextField.setBounds(400,500,50,30);

        add(inTextField);
        add(jTextField);
        add(deTextField);


        final JButton jButton=new JButton("<HTML><U>Enter</U></HTML>");  //加入一个按钮
        final JButton inButton=new JButton("<HTML><U>Enter</U></HTML>"); //新的按钮
        final JButton deButton=new JButton("<HTML><U>Enter</U></HTML>"); //新按钮

        jButton.setFont(new Font("",1,30)); //设置按钮的字体大小
        inButton.setFont(new Font("",1,30));
        deButton.setFont(new Font("",1,30));

        jButton.setBackground(Color.white);  //设置按钮的颜色
        inButton.setBackground(Color.white);
        deButton.setBackground(Color.white);

        jButton.setBounds(280, 450, 50, 30);
        inButton.setBounds(150,550,50,30);
        deButton.setBounds(400,500,50,30);


        deButton.addActionListener(new ActionListener() {//行为监听器
            @Override
            public void actionPerformed(ActionEvent e) {
                if(deButton.equals(deButton.getActionCommand())){  //点下按钮时，该按钮会由白色变成蓝色
                    deButton.setBackground(Color.BLUE);
                }
                try {
                    Frame153.this.avlTree.delete(Integer.parseInt(deTextField.getText()));//删除操作
                    jtree = Frame153.this.avlTree.printTree();
                    addJTree();
                    Frame153 frame=new Frame153(avlTree);
                    update(frame);
                } catch (NumberFormatException err) {//报错
                    JOptionPane.showMessageDialog(null, "输入数字：", "失败", JOptionPane.ERROR_MESSAGE);
                    deTextField.setText("");
                    err.printStackTrace();
                }
            }
        });

        jButton.addActionListener(new ActionListener() { //加入活动的监听
            @Override
            public void actionPerformed(ActionEvent e) {
                if(jButton.equals(jButton.getActionCommand())){ //同理白变蓝
                    jButton.setBackground(Color.BLUE);
                }
                try{
                    int id=Integer.parseInt(jTextField.getText()); //爬下来id值
                    Node fruit=avlTree.get(id);
                    boolean isTrue=true;
                    if(fruit!=null){
                        isTrue=true;
                    }else{
                        isTrue=false;
                    }
                    if(true){  //id不为空时输出，文本转换；为空时报错
                        fruitLabel.setText(fruit.toString());
                    }else{
                        fruitLabel.setText("搜索失败");
                    }
                }catch(NumberFormatException err){ //错误处理
                    JOptionPane.showMessageDialog(null,"输入数字：","失败",JOptionPane.ERROR_MESSAGE);
                    err.printStackTrace();
                }
            }
        });
        inButton.addActionListener(new ActionListener() { //新的行为监听器
            @Override
            public void actionPerformed(ActionEvent e) {
                if(inButton.equals(inButton.getActionCommand())){ //也是按下去时白色变成蓝色
                    inButton.setBackground(Color.BLUE);
                }
                try{
                    String[] text=inTextField.getText().split("\\+");
                    boolean isTrue=true;
                    if(text.length==2){
                        isTrue=true;
                    }else{
                        isTrue=false;
                    }
                    if(true){  //根据输入的Text对应找到其id及data
                        int id=Integer.parseInt(text[0]);//text的第一段为id ,第二段为data
                        Node node=new Node();
                        node.setId(id);
                        String data=text[1];
                        node.setData(data);
                        Frame153.this.avlTree.insert(node);//插入avlTree
                        jtree=Frame153.this.avlTree.printTree();//显示avlTree
                        addJTree();
                        Frame153 frame=new Frame153(avlTree);
                        update(frame);
                    }else{ //报错
                        JOptionPane.showMessageDialog(null,"您输入的格式错误","失败",JOptionPane.ERROR_MESSAGE);
                    }
                }catch(NumberFormatException err){
                    JOptionPane.showMessageDialog(null,"输入数字：","失败" ,JOptionPane.ERROR_MESSAGE);
                    inTextField.setText("");
                    err.printStackTrace();
                }
            }
        });
        add(jButton);
        add(inButton);
        add(deButton);

    }

    private void update(Frame153 frame) {
        this.setVisible(false);
        frame.setVisible(true);
    }

    private void addJTree(){  //将实例化的二叉树加入的函数
        while(jtree!=null){
            jtree.setVisible(true);
            jtree.setBounds(50, 30, 500, 300);
            add(jtree);
        }
    }
}


class ImagePanel extends JPanel {  //添加背景图片的类

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        ImageIcon icon = new ImageIcon("./src/bg.png"); //用ImageIcon添加图片
        g.drawImage(icon.getImage(), 0, 0, this.getWidth(), this.getHeight(), this);
    }

}