import javax.swing.JTree;

public interface IAVLTree {
	/**
	 * get the node by index
	 * , the node id to get
	 *
	 */
	Node get(int id);
	/**
	 * insert the node by id
	 */
	void insert(Node newNode);
	/**
	 * the node id to delete
	 *
	 */
	void delete(int id);
	/**
	 * print the whole tree
	 *  a java swing Object JTree
	 */
	JTree printTree();

}
