/**
 * Created by gaoxueting on 16/1/3.
 */
import java.io.*;

public class main{

    public static void main(AVLTree153 avlTree) throws IOException {

        AVLTree153 avlTree153 = new AVLTree153();
        initTree(avlTree);
        showTree(avlTree);
    }
      public static void initTree(AVLTree153 avlTree) throws IOException {
          int id;
          String data;
          String emp;//用以暂存text的String
          BufferedReader bufferedReader = null;//bufferedReader可以从文件中读取字符串
          bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream("data.dat")));
          //新建一个用以读取文件的Reader
          boolean isTrue = true;
          if ((emp = bufferedReader.readLine()) != null) {
              isTrue = true;
              Node node = new Node();
              String[] text = emp.split("\\#");
              id = Integer.parseInt(text[1]);//分别爬取ID和data
              data = text[0];
              node.setId(id); //设置id和data
              node.setData(data);
              avlTree.insert(node);//添加节点
          } else {
              isTrue = false;
          }
      }
    public static void showTree(AVLTree153 avlTree) {
        Frame153 frame = new Frame153(avlTree);  //让GUI界面可视化
        frame.setVisible(true);
    }

}
