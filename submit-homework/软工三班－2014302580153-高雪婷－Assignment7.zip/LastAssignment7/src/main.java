/**
 * Created by gaoxueting on 16/1/3.
 */
import java.io.*;

public class main {

    public static void main(String[] args) {
        AVLTree153 avlTree = makeAVLTree("./src/data.dat"); //建造一棵平衡二叉树
        Frame153 frame = new Frame153(avlTree);  //让GUI界面可视化
        frame.setVisible(true);
    }

    private static AVLTree153 makeAVLTree(String path) {  //建造树的函数

        AVLTree153 avlTree = new AVLTree153();     //新建一棵树
        File file = new File(path);          //新建一个文件
        BufferedReader bufferedReader = null;//bufferedReader可以从文件中读取字符串

        try {
            bufferedReader = new BufferedReader(new FileReader(file));//新建一个用以读取文件的FileReader
            String emp;//用以暂存text的String
            int id;
            String data;

            while ((emp = bufferedReader.readLine()) != null) {//当读取到的不为空时
                String[] text = emp.split("\\#");
                id = Integer.parseInt(text[1]);//分别爬取ID和data
                data = text[0];
                Node node = new Node();
                node.setId(id); //设置id和data
                node.setData(data);
                avlTree.insert(node);//添加节点
            }
        } catch (FileNotFoundException e) { //报错
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return avlTree;
    }
}